<?php
 include_once("dbconnect.php");
 $sqllist = "SELECT * FROM `tbl_beats`";
 
$result = $conn->query($sqllist);

?>

 <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>BEAT</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        </style>
    </head>

    <body class="w3-border">
        <div>
             <?php
             if ($result->num_rows > 0) {
                        echo "<p class='w3-center'><b>Number of data ($number_of_result FOUND)<br></p></b><hr>";
                    echo "<div class='w3-container' style='overflow-x:auto;height:800px'>";
                        echo "<table class='w3-table w3-striped'>
                     <tr><th>No</th><th>Beat</th><th>Date</th></tr>";
                while ($row = $result->fetch_assoc()) {
                          $i++;
                           $beat = $row['beat_val'];
                           $date = $row['beat_date'];
                          echo "<tr><td>$i</td><td>$beat</td><td>$date</td></tr>";
                    
                    }
                      echo "</table>";
                       echo "</div></div>";
             }
                 
             ?>
        </div>
        <div class="w3-button w3-yellow">Press ME</div>
    </body>
    </html>